import discord
from discord.ext import commands
import random
import asyncio
import sqlite3
import os
import json

class CurrencySystem(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.db_path = os.path.join(os.path.dirname(__file__), 'currency.db')
        self.balance_file = os.path.join(os.path.dirname(__file__), 'balance.json')
        
        self.load_bot_balance()

        # Initialize database
        self.conn = sqlite3.connect(self.db_path)
        self.c = self.conn.cursor()
        self.c.execute('''
            CREATE TABLE IF NOT EXISTS Users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                balance INTEGER DEFAULT 0
            )
        ''')
        self.conn.commit()

        # Initialize card values
        self.card_values = {
            '1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6,
            '7': 7, '8': 8, '9': 9, '10': 10,
            'J': 10, 'Q': 10, 'K': 10, 'A': 11,
        }

        # Initialize trivia questions
        self.trivia_questions = [
    {"question": "What is the capital of Germany?", "answer": "berlin"},
    {"question": "Who painted 'The Starry Night'?", "answer": "vincent van gogh"},
    {"question": "What is the hardest natural substance on Earth?", "answer": "diamond"},
    {"question": "What is the largest planet in our solar system?", "answer": "jupiter"},
    {"question": "What element does 'O' represent on the periodic table?", "answer": "oxygen"},
    {"question": "In which country did the Olympic Games originate?", "answer": "greece"},
    {"question": "What is the smallest country in the world by land area?", "answer": "vatican city"},
    {"question": "Which planet is known as the Red Planet?", "answer": "mars"},
    {"question": "Who wrote 'Pride and Prejudice'?", "answer": "jane austen"},
    {"question": "What is the largest mammal in the world?", "answer": "blue whale"},
    {"question": "What is the chemical symbol for silver?", "answer": "ag"},
    {"question": "In what year did the Titanic sink?", "answer": "1912"},
    {"question": "Who was the first person to walk on the moon?", "answer": "neil armstrong"},
    {"question": "What is the capital of Canada?", "answer": "ottawa"},
    {"question": "Which planet is known as the Morning Star?", "answer": "venus"},
    {"question": "What is the main ingredient in traditional Japanese sushi?", "answer": "rice"},
    {"question": "What is the largest desert in the world?", "answer": "sahara"},
    {"question": "Who is known as the 'Father of Modern Physics'?", "answer": "albert einstein"},
    {"question": "What is the smallest prime number?", "answer": "2"},
    {"question": "What is the name of the longest river in the world?", "answer": "nile"},
    {"question": "What is the main ingredient in guacamole?", "answer": "avocado"},
    {"question": "Who invented the telephone?", "answer": "alexander graham bell"},
    {"question": "What is the capital of Australia?", "answer": "canberra"},
    {"question": "Which ocean is the largest?", "answer": "pacific"},
    {"question": "What is the name of the galaxy we live in?", "answer": "milky way"},
    {"question": "Which famous ship sank on its maiden voyage in 1912?", "answer": "titanic"},
    {"question": "What is the name of the first manned mission to land on the Moon?", "answer": "apollo 11"},
    {"question": "Who was the 16th President of the United States?", "answer": "abraham lincoln"},
    {"question": "What is the most abundant gas in Earth's atmosphere?", "answer": "nitrogen"},
    {"question": "Which element has the atomic number 1?", "answer": "hydrogen"},
    {"question": "What is the capital city of Japan?", "answer": "tokyo"},
    {"question": "Who wrote the 'Harry Potter' series?", "answer": "j.k. rowling"},
    {"question": "What is the boiling point of water in Celsius?", "answer": "100"},
    {"question": "Which artist is known for his work 'The Persistence of Memory'?", "answer": "salvador dali"},
    {"question": "What is the longest river in South America?", "answer": "amazon"},
    {"question": "Which scientist is known for the theory of evolution?", "answer": "charles darwin"},
    {"question": "What is the most spoken language in the world?", "answer": "mandarin"},
    {"question": "What is the currency of the United Kingdom?", "answer": "pound"},
    {"question": "What is the capital city of Spain?", "answer": "madrid"},
    {"question": "Who wrote 'The Great Gatsby'?", "answer": "f. scott fitzgerald"},
    {"question": "What is the capital city of Brazil?", "answer": "brasília"},
    {"question": "What is the chemical symbol for lead?", "answer": "pb"},
    {"question": "Who was the 44th President of the United States?", "answer": "barack obama"},
    {"question": "Which planet is known for its rings?", "answer": "saturn"},
    {"question": "Who discovered penicillin?", "answer": "alexander fleming"},
    {"question": "What is the largest island in the Mediterranean Sea?", "answer": "sicily"},
    {"question": "Which country is known as the Land of the Rising Sun?", "answer": "japan"},
    {"question": "What is the name of the world's largest ocean?", "answer": "pacific"},
    {"question": "Who painted 'The Last Supper'?", "answer": "leonardo da vinci"},
    {"question": "What is the smallest planet in our solar system?", "answer": "mercury"},
    {"question": "Which novel starts with the line 'It was the best of times, it was the worst of times'? ", "answer": "a tale of two cities"},
    {"question": "What is the capital city of South Korea?", "answer": "seoul"},
    {"question": "What is the main language spoken in Brazil?", "answer": "portuguese"},
    {"question": "What is the chemical symbol for iron?", "answer": "fe"},
    {"question": "What is the name of the author who wrote 'The Hobbit'?", "answer": "j.r.r. tolkien"},
    {"question": "What is the tallest mountain in the world?", "answer": "everest"},
    {"question": "What is the largest city in Australia by population?", "answer": "sydney"},
    {"question": "Who was the first woman to win a Nobel Prize?", "answer": "marie curie"},
    {"question": "What is the smallest bone in the human body?", "answer": "stapes"},
    {"question": "Which famous scientist formulated the laws of motion and universal gravitation?", "answer": "isaac newton"},
    {"question": "What is the capital of Egypt?", "answer": "cairo"},
    {"question": "Who wrote 'The Catcher in the Rye'?", "answer": "j.d. salinger"},
    {"question": "What is the name of the current monarch of the United Kingdom?", "answer": "king charles iii"},
    {"question": "What is the capital city of Argentina?", "answer": "buenos aires"},
    {"question": "Which country is home to the Great Barrier Reef?", "answer": "australia"},
    {"question": "What is the chemical symbol for sodium?", "answer": "na"},
    {"question": "Who was the first female Prime Minister of the United Kingdom?", "answer": "margaret thatcher"},
    {"question": "What is the largest organ in the human body?", "answer": "skin"},
    {"question": "Which famous landmark is located in Paris, France?", "answer": "eiffel tower"},
    {"question": "What is the capital city of Italy?", "answer": "rome"},
    {"question": "Who wrote 'The Odyssey'?", "answer": "homer"},
    {"question": "What is the chemical symbol for carbon?", "answer": "c"},
    {"question": "What is the name of the tallest building in the world?", "answer": "burj khalifa"},
    {"question": "What is the currency used in Japan?", "answer": "yen"},
    {"question": "Who painted the Mona Lisa?", "answer": "leonardo da vinci"},
    {"question": "Which planet is known for its Great Red Spot?", "answer": "jupiter"},
    {"question": "What is the largest species of shark?", "answer": "whale shark"},
    {"question": "What is the smallest continent by land area?", "answer": "australia"},
    {"question": "What is the name of the river that runs through Egypt?", "answer": "nile"},
    {"question": "Which famous scientist developed the theory of relativity?", "answer": "albert einstein"},
    {"question": "What is the capital city of Sweden?", "answer": "stockholm"},
    {"question": "Who is the author of 'To Kill a Mockingbird'?", "answer": "harper lee"},
    {"question": "What is the name of the fictional wizarding school in 'Harry Potter'?", "answer": "hogwarts"},
    {"question": "What is the chemical symbol for potassium?", "answer": "k"},
    {"question": "What is the most common element in the universe?", "answer": "hydrogen"},
    {"question": "What is the name of the famous clock tower in London?", "answer": "big ben"},
    {"question": "What is the largest bird in the world?", "answer": "ostrich"},
    {"question": "Which country is known as the Land of Fire and Ice?", "answer": "iceland"},
    {"question": "What is the name of the fictional city where Batman resides?", "answer": "gotham city"},
    {"question": "What is the most spoken language in the world?", "answer": "mandarin"},
    {"question": "Who wrote 'The Divine Comedy'?", "answer": "dante alighieri"},
    {"question": "Which animal is known as the 'King of the Jungle'?", "answer": "lion"},
    {"question": "What is the capital of Norway?", "answer": "oslo"},
    {"question": "Who discovered the law of gravity?", "answer": "isaac newton"},
    {"question": "What is the largest continent by land area?", "answer": "asia"},
    {"question": "What is the chemical symbol for mercury?", "answer": "hg"},
    {"question": "What is the name of the star at the center of our solar system?", "answer": "sun"},
    {"question": "Who is the author of '1984'?", "answer": "george orwell"},
    {"question": "Which ocean is to the east of Africa?", "answer": "indian"},
    {"question": "What is the hardest natural substance found in nature?", "answer": "diamond"},
    {"question": "Who was the first person to climb Mount Everest?", "answer": "edmund hillary and tenzing norgay"},
    {"question": "What is the capital city of Portugal?", "answer": "lisbon"},
    {"question": "Which planet is known as the 'Blue Planet'?", "answer": "earth"},
    {"question": "Who wrote 'The Chronicles of Narnia'?", "answer": "c.s. lewis"},
    {"question": "What is the chemical symbol for gold?", "answer": "au"},
    {"question": "Which country is known for inventing pizza?", "answer": "italy"},
    {"question": "What is the largest island in the world?", "answer": "greenland"},
    {"question": "What is the capital city of Kenya?", "answer": "nairobi"},
    {"question": "Who painted 'The Birth of Venus'?", "answer": "sandro botticelli"},
    {"question": "What is the longest river in Asia?", "answer": "yangtze"},
    {"question": "Which animal is the largest land carnivore?", "answer": "polar bear"},
    {"question": "Who was the famous female pilot known for her solo flight across the Atlantic?", "answer": "amelia earhart"},
    {"question": "What is the largest internal organ in the human body?", "answer": "liver"},
    {"question": "What is the name of the famous French pastry often filled with cream?", "answer": "croissant"},
    {"question": "Who wrote 'The Catcher in the Rye'?", "answer": "j.d. salinger"},
    {"question": "Which ocean is the smallest and shallowest?", "answer": "arctic"},
    {"question": "What is the chemical symbol for calcium?", "answer": "ca"},
    {"question": "Who was the Greek goddess of wisdom?", "answer": "athena"},
    {"question": "What is the name of the fictional land where the 'Lord of the Rings' series takes place?", "answer": "middle earth"},
    {"question": "Which country is famous for its tulip fields?", "answer": "netherlands"},
    {"question": "What is the name of the ship that brought the Pilgrims to America in 1620?", "answer": "mayflower"},
    {"question": "What is the tallest waterfall in the world?", "answer": "angel falls"},
    {"question": "Who is the author of 'The Lord of the Rings' trilogy?", "answer": "j.r.r. tolkien"},
    {"question": "What is the most populous city in the world?", "answer": "tokyo"},
    {"question": "Who painted 'The Persistence of Memory'?", "answer": "salvador dali"},
    {"question": "What is the capital city of Turkey?", "answer": "ankara"},
    {"question": "What is the hardest natural substance on Earth?", "answer": "diamond"},
    {"question": "What is the smallest bird in the world?", "answer": "bee hummingbird"},
    {"question": "Which famous scientist is known for his theory of general relativity?", "answer": "albert einstein"},
    {"question": "What is the capital city of India?", "answer": "new delhi"},
    {"question": "Who discovered penicillin?", "answer": "alexander fleming"},
    {"question": "What is the capital city of Mexico?", "answer": "mexico city"},
    {"question": "What is the smallest country in Africa?", "answer": "seychelles"},
    {"question": "What is the capital city of Vietnam?", "answer": "hanoi"},
    {"question": "What is the currency used in Japan?", "answer": "yen"},
    {"question": "Who wrote the novel 'Moby-Dick'?", "answer": "herman melville"},
    {"question": "What is the name of the largest moon of Saturn?", "answer": "titan"},
    {"question": "Which planet is known for its prominent ring system?", "answer": "saturn"},
    {"question": "What is the name of the famous clock tower in London?", "answer": "big ben"},
    {"question": "Who wrote the play 'Romeo and Juliet'?", "answer": "william shakespeare"},
    {"question": "Which chemical element has the symbol 'Au'?", "answer": "gold"},
    {"question": "What is the tallest mountain in Africa?", "answer": "kilimanjaro"},
    {"question": "What is the chemical symbol for sodium?", "answer": "na"},
    {"question": "What is the capital city of Argentina?", "answer": "buenos aires"},
    {"question": "What is the primary language spoken in Brazil?", "answer": "portuguese"},
    {"question": "Who wrote 'The Hobbit'?", "answer": "j.r.r. tolkien"},
    {"question": "What is the chemical symbol for potassium?", "answer": "k"},
    {"question": "Who was the first man to walk on the moon?", "answer": "neil armstrong"},
    {"question": "Which country is home to the Great Barrier Reef?", "answer": "australia"},
    {"question": "What is the largest island in the Mediterranean Sea?", "answer": "sicily"},
    {"question": "What is the smallest unit of life that can function independently?", "answer": "cell"},
    {"question": "Who wrote 'The Da Vinci Code'?", "answer": "dan brown"},
    {"question": "Which city is known as the 'City of Lights'?", "answer": "paris"},
    {"question": "What is the capital of Sweden?", "answer": "stockholm"},
    {"question": "Which animal is known for its ability to change colors?", "answer": "chameleon"},
    {"question": "What is the name of the process by which plants make their own food?", "answer": "photosynthesis"},
    {"question": "Who was the 16th President of the United States?", "answer": "abraham lincoln"},
    {"question": "What is the name of the river that flows through Egypt?", "answer": "nile"},
    {"question": "What is the largest planet in our solar system?", "answer": "jupiter"},
    {"question": "Which famous scientist developed the theory of relativity?", "answer": "albert einstein"},
    {"question": "What is the name of the large reef system off the coast of Australia?", "answer": "great barrier reef"},
    {"question": "Who painted the 'Mona Lisa'?", "answer": "leonardo da vinci"},
    {"question": "What is the capital of Spain?", "answer": "madrid"},
    {"question": "What is the main ingredient in traditional Japanese sushi?", "answer": "rice"},
    {"question": "What is the name of the largest desert in the world?", "answer": "sahara"},
    {"question": "Who wrote 'To Kill a Mockingbird'?", "answer": "harper lee"},
    {"question": "What is the largest organ in the human body?", "answer": "skin"},
    {"question": "Who was the first person to reach the South Pole?", "answer": "roald amundsen"},
    {"question": "Which city is famous for its canals and gondolas?", "answer": "venice"},
    {"question": "What is the chemical symbol for mercury?", "answer": "hg"},
    {"question": "Who discovered the law of gravity?", "answer": "isaac newton"},
    {"question": "What is the chemical symbol for calcium?", "answer": "ca"},
    {"question": "What is the largest fish in the world?", "answer": "whale shark"},
    {"question": "What is the smallest prime number?", "answer": "2"},
    {"question": "What is the capital city of Norway?", "answer": "oslo"},
    {"question": "What is the name of the famous tower located in Pisa, Italy?", "answer": "leaning tower of pisa"},
    {"question": "Who painted 'The Persistence of Memory'?", "answer": "salvador dali"},
    {"question": "What is the largest ocean on Earth?", "answer": "pacific"},
    {"question": "Who wrote the novel '1984'?", "answer": "george orwell"},
    {"question": "What is the capital of Egypt?", "answer": "cairo"},
    {"question": "What is the currency used in the United Kingdom?", "answer": "pound"},
    {"question": "What is the name of the longest river in South America?", "answer": "amazon"},
    {"question": "Who was the first manned mission to land on the Moon?", "answer": "apollo 11"},
    {"question": "What is the name of the only planet in our solar system that rotates on its side?", "answer": "uranus"},
    {"question": "Who wrote 'The Catcher in the Rye'?", "answer": "j.d. salinger"},
    {"question": "What is the smallest country in the world by land area?", "answer": "vatican city"},
    {"question": "What is the chemical symbol for iron?", "answer": "fe"},
    {"question": "What is the largest island in the world?", "answer": "greenland"},
    {"question": "Who is known as the 'Father of Modern Physics'?", "answer": "albert einstein"},
    {"question": "What is the smallest bird in the world?", "answer": "bee hummingbird"},
    {"question": "What is the capital city of Canada?", "answer": "ottawa"},
    {"question": "What is the main ingredient in traditional Italian risotto?", "answer": "rice"},
    {"question": "Which planet is known as the Morning Star?", "answer": "venus"},
    {"question": "Who painted the 'Girl with a Pearl Earring'?", "answer": "johannes vermeer"},
    {"question": "What is the chemical symbol for tungsten?", "answer": "w"},
    {"question": "What is the name of the fictional detective created by Arthur Conan Doyle?", "answer": "sherlock holmes"},
    {"question": "What is the capital city of Turkey?", "answer": "ankara"},
    {"question": "What is the largest island in the Mediterranean Sea?", "answer": "sicily"},
    {"question": "What is the chemical symbol for potassium?", "answer": "k"},
    {"question": "What is the largest species of shark?", "answer": "whale shark"},
    {"question": "What is the capital of Brazil?", "answer": "brasília"},
    {"question": "Who wrote 'Pride and Prejudice'?", "answer": "jane austen"},
    {"question": "What is the most common element in the universe?", "answer": "hydrogen"},
    {"question": "What is the chemical symbol for silver?", "answer": "ag"},
    {"question": "Who discovered the law of universal gravitation?", "answer": "isaac newton"},
    {"question": "What is the name of the famous landmark located in New York Harbor?", "answer": "statue of liberty"},
    {"question": "Who painted 'The Birth of Venus'?", "answer": "sandro botticelli"},
    {"question": "What is the name of the largest volcano in the solar system?", "answer": "olympus mons"},
    {"question": "Who wrote 'The Great Gatsby'?", "answer": "f. scott fitzgerald"},
    {"question": "What is the capital city of the Netherlands?", "answer": "amsterdam"},
    {"question": "What is the chemical symbol for zinc?", "answer": "zn"},
    {"question": "Which planet is known as the Red Planet?", "answer": "mars"},
    {"question": "What is the currency used in Japan?", "answer": "yen"},
    {"question": "What is the capital city of Switzerland?", "answer": "bern"},
    {"question": "What is the chemical symbol for lead?", "answer": "pb"},
    {"question": "What is the largest island in the Mediterranean?", "answer": "sicily"},
    {"question": "Who wrote 'Jane Eyre'?", "answer": "charlotte brontë"},
    {"question": "What is the capital city of Argentina?", "answer": "buenos aires"},
    {"question": "Who was the first woman to win a Nobel Prize?", "answer": "marie curie"},
    {"question": "What is the name of the highest mountain in North America?", "answer": "denali"},
    {"question": "What is the largest desert in the world?", "answer": "sahara"},
    {"question": "Who is the author of 'The Hunger Games'?", "answer": "suzanne collins"},
    {"question": "What materials do you need to craft a crafting table in Minecraft", "answer": "4 wooden planks"},
    {"question": "What year did World War 2 Start", "answer": "1939"},
    {"question": "fortnite", "answer": "Hey it's me goku"},
    {"question": "Who is the main antagonist in the super mario games?", "answer": "bowser"},
    {"question": "Who alone is known as the honored one", "answer": "satoru gojo"},
    {"question": "Which contry was invated first during world war 2?", "answer": "Poland"},
    {"question": "What is 1 + 1", "answer": "2"},
    {"question": "What is the currency used in Mexico?", "answer": "peso"},
    {"question": "What is the largest planet in our solar system?", "answer": "jupiter"},
    {"question": "Who discovered the structure of DNA?", "answer": "james watson and francis crick"},
    {"question": "What is the name of the famous clock tower in London?", "answer": "big ben"},
    {"question": "What is the chemical symbol for nitrogen?", "answer": "n"},
    {"question": "What is the capital city of Greece?", "answer": "athens"},
    {"question": "Who was the first person to reach the North Pole?", "answer": "robert peary"},
    {"question": "What is the name of the world's largest ocean?", "answer": "pacific"},
    {"question": "Who wrote 'The Chronicles of Narnia' series?", "answer": "c.s. lewis"},
    {"question": "What is the capital city of South Korea?", "answer": "seoul"},
    {"question": "Which ocean is the largest by volume?", "answer": "pacific"},
    {"question": "What is the chemical symbol for helium?", "answer": "he"},
    {"question": "What is the most populous city in the world?", "answer": "tokyo"},
    {"question": "Who painted 'The Night Watch'?", "answer": "rembrandt"},
    {"question": "What is the currency of Canada?", "answer": "canadian dollar"},
    {"question": "What is the smallest unit of life?", "answer": "cell"},
    {"question": "What is the capital city of Peru?", "answer": "lima"},
    {"question": "What is the chemical symbol for platinum?", "answer": "pt"},
    {"question": "Who was the first manned mission to the moon?", "answer": "apollo 11"},
    {"question": "What is the name of the largest moon of Jupiter?", "answer": "ganymede"},
    {"question": "What is the currency of Italy?", "answer": "euro"},
    {"question": "Who painted 'The Creation of Adam'?", "answer": "michelangelo"},
    {"question": "What is the chemical symbol for copper?", "answer": "cu"},
    {"question": "What is the smallest continent by land area?", "answer": "australia"},
    {"question": "Who wrote 'Wuthering Heights'?", "answer": "emily brontë"},
    {"question": "What is the capital of Argentina?", "answer": "buenos aires"},
    {"question": "What is the name of the longest river in Africa?", "answer": "nile"},
    {"question": "What is the chemical symbol for mercury?", "answer": "hg"},
    {"question": "What is the currency used in China?", "answer": "renminbi"},
    {"question": "What is the largest city in South America by population?", "answer": "são paulo"},
    {"question": "Who wrote 'The Da Vinci Code'?", "answer": "dan brown"},
    {"question": "What is the capital city of Nigeria?", "answer": "abuja"},
    {"question": "What is the chemical symbol for iodine?", "answer": "i"},
    {"question": "Who was the famous British Prime Minister during World War II?", "answer": "winston churchill"},
    {"question": "What is the currency used in Switzerland?", "answer": "swiss franc"},
    {"question": "Who discovered the circulation of blood?", "answer": "william harvey"},
    {"question": "What is the chemical symbol for sulfur?", "answer": "s"},
    {"question": "What is the name of the world's largest coral reef system?", "answer": "great barrier reef"},
    {"question": "What is the capital city of Hungary?", "answer": "budapest"},
    {"question": "What is the capital of Chile?", "answer": "santiago"},
    {"question": "What is the currency used in South Africa?", "answer": "rand"},
    {"question": "What is the chemical symbol for uranium?", "answer": "u"},
    {"question": "What is the name of the famous monument in India?", "answer": "taj mahal"},
    {"question": "What is the capital city of Malaysia?", "answer": "kuala lumpur"},
    {"question": "Who was the first person to walk in space?", "answer": "alexey leonov"},
    {"question": "What is the name of the famous tower in Paris?", "answer": "eiffel tower"},
    {"question": "What is the chemical symbol for phosphorus?", "answer": "p"},
    {"question": "Who wrote 'The Great Gatsby'?", "answer": "f. scott fitzgerald"},
    {"question": "What is the capital city of Sweden?", "answer": "stockholm"},
    {"question": "What is the chemical symbol for cobalt?", "answer": "co"},
    {"question": "What is the capital city of the United Arab Emirates?", "answer": "abu dhabi"},
    {"question": "Who is known as the 'Father of Computers'?", "answer": "charles babbage"},
    {"question": "What is the largest city in Africa by population?", "answer": "lagos"},
    {"question": "What is the chemical symbol for barium?", "answer": "ba"},
    {"question": "What is the largest island in the Mediterranean Sea?", "answer": "sicily"},
    {"question": "Who wrote 'The Adventures of Sherlock Holmes'?", "answer": "arthur conan doyle"},
    {"question": "What is the chemical symbol for nickel?", "answer": "ni"},
    {"question": "What is the capital city of Indonesia?", "answer": "jakarta"},
    {"question": "What is the currency used in South Korea?", "answer": "won"},
    {"question": "Who painted 'The School of Athens'?", "answer": "raphael"},
    {"question": "What is the name of the famous bridge in San Francisco?", "answer": "golden gate bridge"},
    {"question": "What is the chemical symbol for chromium?", "answer": "cr"},
    {"question": "Who is the famous Greek philosopher known for his method of questioning?", "answer": "socrates"},
    {"question": "What is the capital city of Lebanon?", "answer": "beirut"},
    {"question": "Who discovered the law of electromagnetism?", "answer": "james clerk maxwell"},
    {"question": "What is the currency used in Australia?", "answer": "australian dollar"},
    {"question": "What is the capital city of Portugal?", "answer": "lisbon"},
    {"question": "What is the smallest unit of matter?", "answer": "atom"},
    {"question": "What is the name of the longest river in North America?", "answer": "missouri river"},
    {"question": "Who wrote 'The Catcher in the Rye'?", "answer": "j.d. salinger"},
    {"question": "What is the name of the famous pyramids located in Egypt?", "answer": "pyramids of giza"},
    {"question": "What is the chemical symbol for magnesium?", "answer": "mg"},
    {"question": "What is the capital city of Ireland?", "answer": "dublin"},
    {"question": "What is the smallest planet in our solar system?", "answer": "mercury"},
    {"question": "What is the currency of Canada?", "answer": "canadian dollar"},
    {"question": "What is the chemical symbol for zinc?", "answer": "zn"},
    {"question": "What is the largest island in the Mediterranean Sea?", "answer": "sicily"},
    {"question": "What is the name of the famous amphitheater in Rome?", "answer": "colosseum"},
    {"question": "Who wrote 'Les Misérables'?", "answer": "victor hugo"},
    {"question": "What is the largest land animal?", "answer": "elephant"},
    {"question": "What is the chemical symbol for manganese?", "answer": "mn"},
    {"question": "What is the name of the famous waterfall located in Venezuela?", "answer": "angel falls"},
    {"question": "Who was the famous Russian composer known for 'The Nutcracker'?", "answer": "pyotr ilyich tchaikovsky"},
    {"question": "What is the largest lake in Africa?", "answer": "lake victoria"},
    {"question": "What is the name of the famous statue located in Rio de Janeiro?", "answer": "christ the redeemer"},
    {"question": "What is the smallest planet in the solar system?", "answer": "mercury"},
    {"question": "What is the chemical symbol for potassium?", "answer": "k"},
    {"question": "What is the name of the famous stone structure located in England?", "answer": "stonehenge"},
    {"question": "What is the capital city of Finland?", "answer": "helsinki"},
    {"question": "What is the name of the river that flows through Paris?", "answer": "seine"},
    {"question": "What is the chemical symbol for titanium?", "answer": "ti"},
    {"question": "Who wrote 'Brave New World'?", "answer": "aldous huxley"},
    {"question": "What is the currency used in India?", "answer": "indian rupee"},
    {"question": "What is the capital city of the Philippines?", "answer": "manila"},
    {"question": "Who painted 'The Arnolfini Portrait'?", "answer": "jan van eyck"},
    {"question": "What is the largest living mammal?", "answer": "blue whale"},
    {"question": "What is the name of the process by which plants convert sunlight into energy?", "answer": "photosynthesis"},
    {"question": "What is the currency used in Russia?", "answer": "ruble"},
    {"question": "What is the chemical symbol for lithium?", "answer": "li"},
    {"question": "Who wrote 'The Hobbit'?", "answer": "j.r.r. tolkien"},
    {"question": "What is the capital city of Norway?", "answer": "oslo"},
    {"question": "Who painted 'The Last Supper'?", "answer": "leonardo da vinci"},
    {"question": "What is the largest fish in the world?", "answer": "whale shark"},
    {"question": "What is the chemical symbol for calcium?", "answer": "ca"},
    {"question": "Who discovered the theory of evolution by natural selection?", "answer": "charles darwin"},
    {"question": "What is the name of the famous ancient city located in Greece?", "answer": "athens"},
    {"question": "What is the capital city of Denmark?", "answer": "copenhagen"},
    {"question": "What is the chemical symbol for radon?", "answer": "rn"},
    {"question": "Who wrote 'The Picture of Dorian Gray'?", "answer": "oscar wilde"},
    {"question": "What is the capital city of Mongolia?", "answer": "ulaanbaatar"},
    {"question": "What is the chemical symbol for osmium?", "answer": "os"},
    {"question": "What is the capital city of Bangladesh?", "answer": "dhaka"},
    {"question": "What is the currency used in South Africa?", "answer": "rand"},
    {"question": "Who was the famous artist known for his sculptures of 'David' and 'Pieta'?", "answer": "michelangelo"},
    {"question": "What is the largest ocean by surface area?", "answer": "pacific"},
    {"question": "What is the capital city of Italy?", "answer": "rome"},
    {"question": "What is the chemical symbol for nitrogen?", "answer": "n"},
    {"question": "Who wrote 'The Old Man and the Sea'?", "answer": "ernest hemingway"},
    {"question": "What is the currency used in Argentina?", "answer": "argentine peso"},
    {"question": "What is the smallest continent by land area?", "answer": "australia"},
    {"question": "Who painted 'The Kiss'?", "answer": "gustav klimt"},
    {"question": "What is the chemical symbol for selenium?", "answer": "se"},
    {"question": "What is the largest moon of Neptune?", "answer": "triton"},
    {"question": "Who was the famous civil rights leader known for his 'I Have a Dream' speech?", "answer": "martin luther king jr."},
    {"question": "What is the capital city of Iraq?", "answer": "baghdad"},
    {"question": "What is the currency used in Switzerland?", "answer": "swiss franc"},
    {"question": "Who wrote 'The Road'?", "answer": "cormac mccarthy"},
    {"question": "What is the smallest prime number?", "answer": "2"},
    {"question": "What is the chemical symbol for mercury?", "answer": "hg"},
    {"question": "What is the largest city in Canada by population?", "answer": "toronto"},
    {"question": "What is the currency used in Egypt?", "answer": "egyptian pound"},
    {"question": "Who painted 'The Creation of Adam'?", "answer": "michelangelo"},
    {"question": "What is the chemical symbol for radon?", "answer": "rn"},
    {"question": "What is the capital city of Israel?", "answer": "jerusalem"},
    {"question": "What is the largest lake in North America?", "answer": "lake superior"},
    {"question": "Who wrote 'One Hundred Years of Solitude'?", "answer": "gabriel garcía márquez"},
    {"question": "What is the smallest unit of matter?", "answer": "atom"},
    {"question": "What is the capital city of Croatia?", "answer": "zagreb"},
    {"question": "What is the largest fish in the world?", "answer": "whale shark"},
    {"question": "What is the chemical symbol for strontium?", "answer": "sr"},
    {"question": "What is the smallest unit of life?", "answer": "cell"},
    {"question": "What is the currency used in Turkey?", "answer": "turkish lira"},
    {"question": "Who wrote 'Brave New World'?", "answer": "aldous huxley"},
    {"question": "What is the capital city of Hungary?", "answer": "budapest"},
    {"question": "What is the name of the ancient city located in Iraq?", "answer": "babylon"},
    {"question": "What is the chemical symbol for bromine?", "answer": "br"},
    {"question": "Who wrote 'The Catcher in the Rye'?", "answer": "j.d. salinger"},
    {"question": "blue", "answer": "fortnite"}
        ]

    def load_bot_balance(self):
        """Load the bot's balance from the JSON file."""
        if os.path.exists(self.balance_file):
            try:
                with open(self.balance_file, 'r') as f:
                    data = json.load(f)
                    self.bot_balance = data.get('bot_balance', 0)
            except json.JSONDecodeError:
                self.bot_balance = 0
                print("Error: Failed to decode JSON. Setting bot balance to 0.")
        else:
            self.bot_balance = 0

    def save_bot_balance(self):
        """Save the bot's balance to the JSON file."""
        with open(self.balance_file, 'w') as f:
            json.dump({'bot_balance': self.bot_balance}, f)

    def get_balance(self, user_id):
        self.c.execute('SELECT balance FROM Users WHERE user_id = ?', (user_id,))
        result = self.c.fetchone()
        return result[0] if result else 0

    def update_balance(self, user, amount):
        user_id = user.id
        username = str(user)
        current_balance = self.get_balance(user_id)
        new_balance = current_balance + amount
        if new_balance < 0:
            new_balance = 0
        
        self.c.execute('SELECT user_id FROM Users WHERE user_id = ?', (user_id,))
        if self.c.fetchone() is None:
            self.c.execute('INSERT INTO Users (user_id, username, balance) VALUES (?, ?, ?)',
                           (user_id, username, new_balance))
        else:
            self.c.execute('UPDATE Users SET username = ?, balance = ? WHERE user_id = ?',
                           (username, new_balance, user_id))
        
        self.conn.commit()
        return new_balance

    def update_bot_balance(self, amount):
        """Update the bot's balance and save it."""
        self.bot_balance += amount
        self.save_bot_balance()

    def draw_card(self):
        """Draw a random card from a deck."""
        return random.choice(list(self.card_values.keys()))

    def calculate_hand_value(self, hand):
        """Calculate the total value of a hand."""
        total = sum(self.card_values[card] for card in hand)
        num_aces = hand.count('A')

        while total > 21 and num_aces:
            total -= 10
            num_aces -= 1

        return total

    @commands.command(name="blackjack")
    async def play_blackjack(self, ctx, bet: int):
        user = ctx.author

        balance = self.get_balance(user.id)
        if balance < bet:
            await ctx.send(f"{user.mention}, you don't have enough coins to place this bet.")
            return

        if bet < 1:
            await ctx.send(f"{user.mention}, you need to bet at least 1 coin.")
            return

        player_hand = [self.draw_card(), self.draw_card()]
        dealer_hand = [self.draw_card(), self.draw_card()]

        player_value = self.calculate_hand_value(player_hand)
        dealer_value = self.calculate_hand_value(dealer_hand)

        embed = discord.Embed(title="Blackjack", color=discord.Color.green())
        embed.add_field(name="Your Hand", value=f"{player_hand} (total: {player_value})")
        embed.add_field(name="Dealer's Visible Card", value=f"{dealer_hand[0]}")
        embed.add_field(name="Action", value="Do you want to `hit` or `stand`?")

        message = await ctx.send(embed=embed)

        while player_value < 21:
            def check(msg):
                return msg.author == user and msg.content.lower() in ["hit", "stand"] and msg.channel == ctx.channel

            try:
                msg = await self.bot.wait_for('message', check=check, timeout=30.0)
            except asyncio.TimeoutError:
                await ctx.send(f"{user.mention}, you took too long. Standing by default.")
                break

            if msg.content.lower() == "stand":
                break
            elif msg.content.lower() == "hit":
                player_hand.append(self.draw_card())
                player_value = self.calculate_hand_value(player_hand)
                embed.set_field_at(0, name="Your Hand", value=f"{player_hand} (total: {player_value})")
                try:
                    await message.edit(embed=embed)
                except discord.DiscordException as e:
                    await ctx.send(f"Failed to update message: {e}")
                    return

                if player_value >= 21:
                    break

        dealer_hand_str = f"{dealer_hand} (total: {dealer_value})"
        while dealer_value < 17:
            dealer_hand.append(self.draw_card())
            dealer_value = self.calculate_hand_value(dealer_hand)
            dealer_hand_str = f"{dealer_hand} (total: {dealer_value})"
            embed.set_field_at(1, name="Dealer's Hand", value=dealer_hand_str)
            try:
                await message.edit(embed=embed)
            except discord.DiscordException as e:
                await ctx.send(f"Failed to update message: {e}")
                return
            await asyncio.sleep(1)

        if player_value > 21:
            result = f"You busted! You lose {bet} coins."
            new_balance = self.update_balance(user, -bet)
            self.update_bot_balance(bet)
        elif dealer_value > 21 or player_value > dealer_value:
            result = f"You win! You gain {bet} coins."
            new_balance = self.update_balance(user, bet)
            self.update_bot_balance(-bet)
        elif player_value == dealer_value:
            result = "It's a tie! You get your bet back."
            new_balance = self.update_balance(user, 0)
        else:
            result = f"You lose! The dealer wins. You lose {bet} coins."
            new_balance = self.update_balance(user, -bet)
            self.update_bot_balance(bet)

        embed.set_field_at(2, name="Action", value=result)
        embed.set_footer(text=f"Your new balance is {new_balance} coins.")
        try:
            await message.edit(embed=embed)
        except discord.DiscordException as e:
            await ctx.send(f"Failed to update message: {e}")

    @commands.command(name="blackjack_all")
    async def play_blackjack_all(self, ctx):
        user = ctx.author
        balance = self.get_balance(user.id)
        
        if balance <= 0:
            await ctx.send(f"{user.mention}, you don't have any coins to bet.")
            return

        bet = balance

        player_hand = [self.draw_card(), self.draw_card()]
        dealer_hand = [self.draw_card(), self.draw_card()]

        player_value = self.calculate_hand_value(player_hand)
        dealer_value = self.calculate_hand_value(dealer_hand)

        embed = discord.Embed(title="Blackjack", color=discord.Color.green())
        embed.add_field(name="Your Hand", value=f"{player_hand} (total: {player_value})")
        embed.add_field(name="Dealer's Visible Card", value=f"{dealer_hand[0]}")
        embed.add_field(name="Action", value="Do you want to `hit` or `stand`?")

        message = await ctx.send(embed=embed)

        while player_value < 21:
            def check(msg):
                return msg.author == user and msg.content.lower() in ["hit", "stand"] and msg.channel == ctx.channel

            try:
                msg = await self.bot.wait_for('message', check=check, timeout=30.0)
            except asyncio.TimeoutError:
                await ctx.send(f"{user.mention}, you took too long. Standing by default.")
                break

            if msg.content.lower() == "stand":
                break
            elif msg.content.lower() == "hit":
                player_hand.append(self.draw_card())
                player_value = self.calculate_hand_value(player_hand)
                embed.set_field_at(0, name="Your Hand", value=f"{player_hand} (total: {player_value})")
                try:
                    await message.edit(embed=embed)
                except discord.DiscordException as e:
                    await ctx.send(f"Failed to update message: {e}")
                    return

                if player_value >= 21:
                    break

        dealer_hand_str = f"{dealer_hand} (total: {dealer_value})"
        while dealer_value < 17:
            dealer_hand.append(self.draw_card())
            dealer_value = self.calculate_hand_value(dealer_hand)
            dealer_hand_str = f"{dealer_hand} (total: {dealer_value})"
            embed.set_field_at(1, name="Dealer's Hand", value=dealer_hand_str)
            try:
                await message.edit(embed=embed)
            except discord.DiscordException as e:
                await ctx.send(f"Failed to update message: {e}")
                return
            await asyncio.sleep(1)

        if player_value > 21:
            result = f"You busted! You lose {bet} coins."
            new_balance = self.update_balance(user, -bet)
            self.update_bot_balance(bet)
        elif dealer_value > 21 or player_value > dealer_value:
            result = f"You win! You gain {bet} coins."
            new_balance = self.update_balance(user, bet)
            self.update_bot_balance(-bet)
        elif player_value == dealer_value:
            result = "It's a tie! You get your bet back."
            new_balance = self.update_balance(user, 0)
        else:
            result = f"You lose! The dealer wins. You lose {bet} coins."
            new_balance = self.update_balance(user, -bet)
            self.update_bot_balance(bet)

        embed.set_field_at(2, name="Action", value=result)
        embed.set_footer(text=f"Your new balance is {new_balance} coins.")
        try:
            await message.edit(embed=embed)
        except discord.DiscordException as e:
            await ctx.send(f"Failed to update message: {e}")

    @commands.command(name="balance")
    async def check_balance(self, ctx):
        user = ctx.author
        balance = self.get_balance(user.id)
        await ctx.send(f"{user.mention}, your balance is {balance} coins.")

    @commands.command(name="botbalance")
    async def check_bot_balance(self, ctx):
        """Command to check the bot's balance."""
        embed = discord.Embed(title="Bot Balance", color=discord.Color.gold())
        embed.add_field(name="Bot's Balance", value=f"{self.bot_balance} coins")
        await ctx.send(embed=embed)

    @commands.command(name="slots")
    async def play_slots(self, ctx, bet: int):
        user = ctx.author

        balance = self.get_balance(user.id)
        if balance < bet:
            await ctx.send(f"{user.mention}, you don't have enough coins to place this bet.")
            return

        if bet < 1:
            await ctx.send(f"{user.mention}, you need to bet at least 1 coin.")
            return

        symbols = ['🍒', '🍋', '🍊', '🍉', '🍇', '7️⃣']
        spin_result = [random.choice(symbols) for _ in range(3)]

        embed = discord.Embed(title="Slot Machine", description="Spinning...", color=discord.Color.blue())
        embed.add_field(name="Result", value=f"| {spin_result[0]} | {spin_result[1]} | {spin_result[2]} |")
        message = await ctx.send(embed=embed)

        spin_duration = 5.0
        spin_intervals = 10
        interval = spin_duration / spin_intervals

        for _ in range(spin_intervals):
            spin_result = [random.choice(symbols) for _ in range(3)]
            embed.set_field_at(0, name="Result", value=f"| {spin_result[0]} | {spin_result[1]} | {spin_result[2]} |")
            try:
                await message.edit(embed=embed)
            except discord.DiscordException as e:
                await ctx.send(f"Failed to update message: {e}")
                return
            await asyncio.sleep(interval)

        win = False
        if spin_result[0] == spin_result[1] == spin_result[2]:
            win = True
            win_amount = bet * 10
        else:
            win_amount = -bet

        new_balance = self.update_balance(user, win_amount)
        if win:
            embed.add_field(name="Congratulations!", value=f"You won {win_amount} coins!")
        else:
            embed.add_field(name="Game Over", value=f"You lost {bet} coins.")
        
        embed.set_footer(text=f"Your new balance is {new_balance} coins.")
        try:
            await message.edit(embed=embed)
        except discord.DiscordException as e:
            await ctx.send(f"Failed to update message: {e}")

    @commands.command(name="transfer")
    async def transfer(self, ctx, member: discord.Member, amount: int):
        user = ctx.author

        if amount <= 0:
            await ctx.send(f"{user.mention}, you must transfer a positive amount.")
            return

        balance = self.get_balance(user.id)
        if balance < amount:
            await ctx.send(f"{user.mention}, you don't have enough coins to transfer.")
            return

        self.update_balance(user, -amount)
        self.update_balance(member, amount)

        await ctx.send(f"Successfully transferred {amount} coins to {member.mention}.")
        
    @commands.command(name="trivia")
    async def trivia(self, ctx):
        # Select a random trivia question
        trivia = random.choice(self.trivia_questions)
        question = trivia["question"]
        correct_answer = trivia["answer"]

        # Create an embed for the trivia question
        embed = discord.Embed(
            title="Trivia Time!",
            description=f"**Question:** {question}",
            color=discord.Color.blue()
        )

        # Send the trivia question
        try:
            await ctx.send(embed=embed)
        except discord.DiscordException as e:
            print(f"Failed to send trivia question: {e}")
            await ctx.send("An error occurred while sending the trivia question.")
            return

        # Function to check the user's answer
        def check(msg):
            return msg.author == ctx.author and msg.channel == ctx.channel

        # Wait for the user's response
        try:
            msg = await self.bot.wait_for('message', check=check, timeout=30.0)
            user_answer = msg.content.lower()

            if correct_answer in user_answer:
                amount = 10000
                new_balance = self.update_balance(ctx.author, amount)
                result_embed = discord.Embed(
                    title="Correct!",
                    description=f"You've been awarded {amount} coins.",
                    color=discord.Color.green()
                )
                result_embed.add_field(name="Your New Balance", value=f"{new_balance} coins")
                await ctx.send(embed=result_embed)
            else:
                result_embed = discord.Embed(
                    title="Incorrect",
                    description="Sorry, that's not correct. Better luck next time!",
                    color=discord.Color.red()
                )
                await ctx.send(embed=result_embed)

        except asyncio.TimeoutError:
            timeout_embed = discord.Embed(
                title="Time's Up!",
                description="You took too long to answer.",
                color=discord.Color.orange()
            )
            await ctx.send(embed=timeout_embed)
        except discord.DiscordException as e:
            print(f"Failed to send response embed: {e}")
            await ctx.send("An error occurred while processing your response.")

async def setup(bot):
    await bot.add_cog(CurrencySystem(bot))