from discord.ext import commands
import discord

class Utility(commands.Cog):
    """A cog for utility commands."""

    def __init__(self, bot):
        self.bot = bot

    @commands.command(name='ping', help='Checks the bot\'s latency.')
    async def ping(self, ctx):
        latency = self.bot.latency
        await ctx.send(f'Pong! Latency is {latency*1000:.2f} ms')

async def setup(bot):
    await bot.add_cog(Utility(bot))