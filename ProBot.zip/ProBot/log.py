 # type: ignore
import discord
from discord.ext import commands
import os

token = 'MTI3MTEwNDM5NTUyMTU2MDY3OA.GF9g4Z.q4a9_6EJlrMHtFvd8omkIbc3iqEdnZFEw5jbXk'  # Replace with your actual bot token


# Ensure log file exists
if not os.path.exists('log.txt'):
    with open('log.txt', 'w+') as file:
        file.write('Log File Created\n')

intents = discord.Intents.default()
intents.message_content = True
intents.messages = True
intents.guilds = True

bot = commands.Bot(command_prefix='~', intents=intents)

def create_embed(description, title, color):
    """Create an embed for logging with a title, description, and color."""
    embed = discord.Embed(
        title=title,
        description=description,
        color=color
    )
    embed.set_footer(text=f"Bot ID: {bot.user.id}")
    return embed

@bot.event
async def on_ready():
    print(f'Logged in as {bot.user.name}')
    print(f'Bot ID: {bot.user.id}')
    print("---------------------------------------")

@bot.event
async def on_message(message):
    if message.author == bot.user:
        return

    timestamp = message.created_at.strftime('%Y-%m-%d %H:%M:%S')
    description = f"{message.author} [{timestamp}] in {message.guild.name}: {message.content}"
    embed = create_embed(description, "Message Sent", discord.Color.green())
    
    # Print the log message to the console
    print(f"Message Sent: {description}")

    # Send the log message to the 'botlogs' channel
    channel = discord.utils.get(message.guild.channels, name='botlogs')
    if channel:
        try:
            await channel.send(embed=embed)
        except Exception as e:
            print(f"Error sending message to channel: {e}")
    else:
        print("Error: Channel 'botlogs' not found.")

    # Process commands
    await bot.process_commands(message)

@bot.event
async def on_message_delete(message):
    if message.author == bot.user:
        return

    timestamp = message.created_at.strftime('%Y-%m-%d %H:%M:%S')
    description = f"{message.author} [{timestamp}] in {message.guild.name}: {message.content}"
    embed = create_embed(description, "Message Deleted", discord.Color.red())
    
    # Print the log message to the console
    print(f"Message Deleted: {description}")

    # Send the log message to the 'botlogs' channel
    channel = discord.utils.get(message.guild.channels, name='botlogs')
    if channel:
        try:
            await channel.send(embed=embed)
        except Exception as e:
            print(f"Error sending message to channel: {e}")
    else:
        print("Error: Channel 'botlogs' not found.")

@bot.event
async def on_message_edit(before, after):
    if before.author == bot.user:
        return

    if before.content != after.content:
        timestamp = after.edited_at.strftime('%Y-%m-%d %H:%M:%S')
        description = (f"**Before:** {before.content}\n"
                       f"**After:** {after.content}")
        embed = create_embed(description, "Message Edited", discord.Color.orange())
        
        # Print the log message to the console
        print(f"Message Edited: {description}")

        # Send the log message to the 'botlogs' channel
        channel = discord.utils.get(after.guild.channels, name='botlogs')
        if channel:
            try:
                await channel.send(embed=embed)
            except Exception as e:
                print(f"Error sending message to channel: {e}")
        else:
            print("Error: Channel 'botlogs' not found.")

@bot.event
async def on_command(ctx):
    """Logs every command used and who used it."""
    timestamp = ctx.message.created_at.strftime('%Y-%m-%d %H:%M:%S')
    description = (f"**User:** {ctx.author}\n"
                   f"**Command:** {ctx.command}\n"
                   f"**Channel:** {ctx.channel}\n"
                   f"**Timestamp:** {timestamp}")
    embed = create_embed(description, "Command Used", discord.Color.blue())
    
    # Print the log message to the console
    print(f"Command Used: {description}")

    # Send the log message to the 'botlogs' channel
    channel = discord.utils.get(ctx.guild.channels, name='botlogs')
    if channel:
        try:
            await channel.send(embed=embed)
        except Exception as e:
            print(f"Error sending message to channel: {e}")
    else:
        print("Error: Channel 'botlogs' not found.")

@bot.event
async def on_interaction(interaction):
    """Logs every application command used and who used it."""
    if interaction.type == discord.InteractionType.application_command:
        timestamp = interaction.created_at.strftime('%Y-%m-%d %H:%M:%S')
        description = (f"**User:** {interaction.user}\n"
                       f"**Command:** {interaction.data['name']}\n"
                       f"**Channel:** {interaction.channel}\n"
                       f"**Timestamp:** {timestamp}")
        embed = create_embed(description, "Application Command Used", discord.Color.purple())
        
        # Print the log message to the console
        print(f"Application Command Used: {description}")

        # Send the log message to the 'botlogs' channel
        channel = discord.utils.get(interaction.guild.channels, name='botlogs')
        if channel:
            try:
                await channel.send(embed=embed)
            except Exception as e:
                print(f"Error sending message to channel: {e}")
        else:
            print("Error: Channel 'botlogs' not found.")

try:
    bot.run(token)
except Exception as e:
    print(f"Error running the bot: {e}")