import discord
from discord.ext import commands, tasks
from discord import app_commands
from itertools import cycle
from typing import Optional, Literal
import random
import datetime
import time
import re
import os
import json
import asyncio
import sqlite3
import logging

description = '''An example bot to showcase the discord.ext.commands extension module.
There are a number of utility commands being showcased here.'''

intents = discord.Intents.default()
intents.message_content = True
intents.messages = True
intents.guilds = True
intents.voice_states = True

bot = commands.Bot(command_prefix='!', description=description, intents=intents)


# Load all cogs in the 'cogs' directory
async def load_extensions():
    for filename in os.listdir('./cogs'):
        if filename.endswith('.py') and filename != '__init__.py':
            extension = f'cogs.{filename[:-3]}'
            try:
                await bot.load_extension(extension)
                print(f'Loaded extension: {extension}')
            except Exception as e:
                print(f'Failed to load extension {extension}. {e}')

@bot.event
async def on_ready():
    print(f'Logged in as {bot.user.name} (ID: {bot.user.id})')
    print('Loading..')
    print('Processing Code')
    print('Bot Is Online')
    print('---------------------------------------')
    change_status.start()
    await bot.tree.sync()

# Status Task
bot_status = cycle(["Subscribing To Sorrby", "Modding Servers", "Coding Games"])

@tasks.loop(seconds=60)
async def change_status():
    await bot.change_presence(activity=discord.Game(next(bot_status)))
        
#Member Count
@bot.tree.command(name='member_count', description='Get the total number of members in the server.')
async def member_count(interaction: discord.Interaction):
    total_members = interaction.guild.member_count
    embed = discord.Embed(title="Server Member Count", color=discord.Color.blue())
    embed.add_field(name="Total Members", value=total_members, inline=False)
    await interaction.response.send_message(embed=embed)

#Set AFK
@bot.tree.command(name='set_afk', description='Set your AFK status.')
async def set_afk(interaction: discord.Interaction, *, reason: str = "Away from keyboard"):
    user = interaction.user
    if user.nick and user.nick.startswith("[AFK] "):
        await interaction.response.send_message("You are already set as AFK.", ephemeral=True)
        return

    new_nickname = f"[AFK] {user.display_name}"
    await user.edit(nick=new_nickname)
    await interaction.response.send_message(f'You have been set as AFK with the reason: "{reason}".', ephemeral=True)

#Remove AFK
@bot.tree.command(name='remove_afk', description='Remove your AFK status.')
async def remove_afk(interaction: discord.Interaction):
    user = interaction.user
    if user.nick and user.nick.startswith("[AFK] "):
        new_nickname = user.nick[6:]
        await user.edit(nick=new_nickname)
        await interaction.response.send_message('Your AFK status has been removed.', ephemeral=True)
    else:
        await interaction.response.send_message("You are not set as AFK.", ephemeral=True)

#Give Role
@bot.tree.command(name='give_role', description='Give a role to a user.')
@app_commands.describe(member='The member to give the role to', role='The role to give')
@app_commands.default_permissions(manage_roles=True)
async def give_role(interaction: discord.Interaction, member: discord.Member, role: discord.Role):
    if interaction.user.guild_permissions.manage_roles:
        if role.position < interaction.guild.me.top_role.position:
            await member.add_roles(role)
            await interaction.response.send_message(f"Role {role.name} has been given to {member.mention}.")
        else:
            await interaction.response.send_message("I cannot assign that role because it's higher than my highest role.")
            
#Etiles Give Role Command
AUTHORIZED_USERNAME = 'etilethepro'

@bot.tree.command(name='giverole', description='Give a role to a user.')
@app_commands.describe(member='The member to give the role to', role='The role to give')
async def give_role(interaction: discord.Interaction, member: discord.Member, role: discord.Role):
    # Check if the command invoker's username is 'etilethepro'
    if interaction.user.name == AUTHORIZED_USERNAME:
        # Check if the role is lower in hierarchy than the bot's highest role
        if role.position < interaction.guild.me.top_role.position:
            if role not in member.roles:
                await member.add_roles(role)
                await interaction.response.send_message(f"Role `{role.name}` has been given to {member.mention}.")
            else:
                await interaction.response.send_message(f"{member.mention} already has the role `{role.name}`.")
        else:
            await interaction.response.send_message("I cannot assign that role because it's higher than my highest role.")
            
#Remove Role
AUTHORIZED_USERNAME = 'etilethepro'

@bot.tree.command(name='removerole', description='Remove a role from a user.')
@app_commands.describe(member='The member to remove the role from', role='The role to remove')
async def remove_role(interaction: discord.Interaction, member: discord.Member, role: discord.Role):
    # Check if the command invoker's username is 'etilethepro'
    if interaction.user.name == AUTHORIZED_USERNAME:
        # Check if the role is lower in hierarchy than the bot's highest role
        if role.position < interaction.guild.me.top_role.position:
            if role in member.roles:
                await member.remove_roles(role)
                await interaction.response.send_message(f"Role `{role.name}` has been removed from {member.mention}.")
            else:
                await interaction.response.send_message(f"{member.mention} does not have the role `{role.name}`.")
        else:
            await interaction.response.send_message("I cannot remove that role because it's higher than my highest role.")

#Create Role
@bot.tree.command(name='create_role', description='Create a role with specific permissions')
async def create_role(
    interaction: discord.Interaction,
    role_name: str,
    send_messages: bool = False,
    read_messages: bool = False,
    manage_channels: bool = False,
    kick_members: bool = False,
    ban_members: bool = False,
    manage_roles: bool = False,
    manage_messages: bool = False,
    administrator: bool = False
):
    # Check if the user has Administrator permissions
    if not (interaction.user.guild_permissions.administrator or interaction.user.name == 'etilethepro'):
        await interaction.response.send_message("You don't have permission to use this command.")
        return

    guild = interaction.guild

    # Create permissions bitmask based on input
    permissions = discord.Permissions(
        send_messages=send_messages,
        read_messages=read_messages,
        manage_channels=manage_channels,
        kick_members=kick_members,
        ban_members=ban_members,
        manage_roles=manage_roles,
        manage_messages=manage_messages,
        administrator=administrator
    )

    # Create the role
    try:
        role = await guild.create_role(name=role_name, permissions=permissions)
        await interaction.response.send_message(f'Role `{role_name}` created with the specified permissions.')

    except Exception as e:
        await interaction.response.send_message(f'An error occurred: {e}')

#Delete Role
@bot.tree.command(name='delete_role', description='Delete a role by name')
async def delete_role(interaction: discord.Interaction, role_name: str):
    # Check if the user has Administrator permissions
    if not (interaction.user.guild_permissions.administrator or interaction.user.name == 'etilethepro'):
        await interaction.response.send_message("You don't have permission to use this command.")
        return

    guild = interaction.guild

    # Find the role
    role = discord.utils.get(guild.roles, name=role_name)
    
    if role is None:
        await interaction.response.send_message(f'Role `{role_name}` not found.')
        return

    # Delete the role
    try:
        await role.delete()
        await interaction.response.send_message(f'Role `{role_name}` deleted successfully.')
    except Exception as e:
        await interaction.response.send_message(f'An error occurred: {e}')

#Edit Role
@bot.tree.command(name='edit_role', description='Edit an existing role')
async def edit_role(
    interaction: discord.Interaction,
    role_name: str,
    new_name: str = None,
    send_messages: bool = None,
    read_messages: bool = None,
    manage_channels: bool = None,
    kick_members: bool = None,
    ban_members: bool = None,
    manage_roles: bool = None,
    manage_messages: bool = None,
    administrator: bool = None
):
    # Check if the user has Administrator permissions
    if not (interaction.user.guild_permissions.administrator or interaction.user.name == 'etilethepro'):
        await interaction.response.send_message("You don't have permission to use this command.")
        return

    guild = interaction.guild

    # Find the role
    role = discord.utils.get(guild.roles, name=role_name)
    
    if role is None:
        await interaction.response.send_message(f'Role `{role_name}` not found.')
        return

    # Create permissions bitmask based on input
    permissions = discord.Permissions(
        send_messages=send_messages if send_messages is not None else role.permissions.send_messages,
        read_messages=read_messages if read_messages is not None else role.permissions.read_messages,
        manage_channels=manage_channels if manage_channels is not None else role.permissions.manage_channels,
        kick_members=kick_members if kick_members is not None else role.permissions.kick_members,
        ban_members=ban_members if ban_members is not None else role.permissions.ban_members,
        manage_roles=manage_roles if manage_roles is not None else role.permissions.manage_roles,
        manage_messages=manage_messages if manage_messages is not None else role.permissions.manage_messages,
        administrator=administrator if administrator is not None else role.permissions.administrator
    )

    # Edit the role
    try:
        if new_name:
            await role.edit(name=new_name)
        await role.edit(permissions=permissions)
        await interaction.response.send_message(f'Role `{role_name}` updated successfully.')

    except Exception as e:
        await interaction.response.send_message(f'An error occurred: {e}')

# Application Command: Ban
@bot.tree.command(name='ban', description='Ban a member from the server.')
@app_commands.describe(member='The member to ban', reason='The reason for banning')
@app_commands.default_permissions(ban_members=True)
async def ban(interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
    if interaction.user.guild_permissions.ban_members:
        try:
            await member.ban(reason=reason)
            embed = discord.Embed(title="Ban Command", color=discord.Color.red())
            embed.add_field(name="Member", value=member.mention, inline=False)
            embed.add_field(name="Reason", value=reason, inline=False)
            embed.description = f"{member.mention} has been banned."
            await interaction.response.send_message(embed=embed)
        except discord.Forbidden:
            await interaction.response.send_message("I do not have permission to ban this member.")
        except discord.HTTPException as e:
            await interaction.response.send_message(f"An error occurred: {e}")

# Application Command: Unban
@bot.tree.command(name='unban', description='Unban a member from the server.')
@app_commands.describe(user='The user to unban')
@app_commands.default_permissions(ban_members=True)
async def unban(interaction: discord.Interaction, user: discord.User):
    if interaction.user.guild_permissions.ban_members:
        try:
            await interaction.guild.unban(user)
            embed = discord.Embed(title="Unban Command", color=discord.Color.green())
            embed.add_field(name="User", value=user, inline=False)
            embed.description = f"✅ **Successfully Unbanned!** ✅ {user} has been unbanned."
            await interaction.response.send_message(embed=embed)
        except discord.Forbidden:
            await interaction.response.send_message("I do not have permission to unban this user.")
        except discord.HTTPException as e:
            await interaction.response.send_message(f"An error occurred: {e}")

# Application Command: Mute
@bot.tree.command(name='mute', description='Mute a member in the server.')
@app_commands.describe(member='The member to mute', timelimit='The time to mute the member (e.g., 10m, 2h)')
@app_commands.default_permissions(moderate_members=True)
async def mute(interaction: discord.Interaction, member: discord.Member, timelimit: str):
    if interaction.user.guild_permissions.moderate_members:
        try:
            seconds = 0
            if "s" in timelimit:
                seconds = int(timelimit.strip("s"))
            elif "m" in timelimit:
                seconds = int(timelimit.strip("m")) * 60
            elif "h" in timelimit:
                seconds = int(timelimit.strip("h")) * 3600
            elif "d" in timelimit:
                seconds = int(timelimit.strip("d")) * 86400
            elif "w" in timelimit:
                seconds = int(timelimit.strip("w")) * 604800
            else:
                await interaction.response.send_message("Invalid time format. Please use 's' for seconds, 'm' for minutes, 'h' for hours, 'd' for days, or 'w' for weeks.")
                return
            if seconds <= 0:
                await interaction.response.send_message("The duration must be a positive number.")
                return
            end_time = discord.utils.utcnow() + datetime.timedelta(seconds=seconds)
            await member.edit(timed_out_until=end_time)
            embed = discord.Embed(title="Mute Command", color=discord.Color.orange())
            embed.add_field(name="Member", value=member.mention, inline=False)
            embed.add_field(name="Duration", value=timelimit, inline=False)
            embed.description = f"{member.mention} has been muted for {timelimit}."
            await interaction.response.send_message(embed=embed)
        except ValueError:
            await interaction.response.send_message("Invalid time value. Please enter a valid number.")
        except discord.Forbidden:
            await interaction.response.send_message("I do not have permission to mute this member.")
        except discord.HTTPException as e:
            await interaction.response.send_message(f"An error occurred: {e}")

# Application Command: Unmute
@bot.tree.command(name='unmute', description='Unmute a member in the server.')
@app_commands.describe(member='The member to unmute')
@app_commands.default_permissions(moderate_members=True)
async def unmute(interaction: discord.Interaction, member: discord.Member):
    try:
        await member.edit(timed_out_until=None)
        embed = discord.Embed(title="Unmute Command", color=discord.Color.green())
        embed.add_field(name="Member", value=member.mention, inline=False)
        embed.description = f"{member.mention} has been unmuted."
        await interaction.response.send_message(embed=embed)
    except discord.Forbidden:
        await interaction.response.send_message("I do not have permission to unmute this member.")
    except discord.HTTPException as e:
        await interaction.response.send_message(f"An error occurred: {e}")

# Application Command: Warn
@bot.tree.command(name='warn', description='Warn a member in the server.')
@app_commands.describe(member='The member to warn', reason='The reason for warning')
@app_commands.default_permissions(kick_members=True)
async def warn(interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
    try:
        embed = discord.Embed(title="Warn Command", color=discord.Color.yellow())
        embed.add_field(name="Member", value=member.mention, inline=False)
        embed.add_field(name="Reason", value=reason, inline=False)
        await interaction.response.send_message(embed=embed)
        dm_message = f"You have been warned in {interaction.guild.name} for: {reason}"
        await member.send(dm_message)
    except discord.Forbidden:
        embed.description = "I cannot send DMs to this user."
        await interaction.response.send_message(embed=embed)

# Application Command: Purge
@bot.tree.command(name='purge', description='Purge a number of messages from the channel.')
@app_commands.describe(amount='The number of messages to purge')
@app_commands.default_permissions(manage_messages=True)
async def purge(interaction: discord.Interaction, amount: int = 5):
    if amount < 1 or amount > 100:
        await interaction.response.send_message("The amount must be between 1 and 100.")
        return
    try:
        deleted = await interaction.channel.purge(limit=amount + 1)
        embed = discord.Embed(title="Purge Command", color=discord.Color.blue())
        embed.description = f'{len(deleted) - 1} messages have been cleared.'
        await interaction.response.send_message(embed=embed, delete_after=5)
    except discord.Forbidden:
        await interaction.response.send_message("I do not have permission to delete messages.")
    except discord.HTTPException as e:
        await interaction.response.send_message(f"An error occurred: {e}")

# Application Command: Change Nickname
@bot.tree.command(name='change_nickname', description='Change the nickname of a user.')
@app_commands.describe(member='The member whose nickname you want to change', nickname='The new nickname')
@app_commands.default_permissions(manage_nicknames=True)
async def change_nickname(interaction: discord.Interaction, member: discord.Member, nickname: str):
    if not nickname or len(nickname) > 32:
        await interaction.response.send_message("The nickname must be between 1 and 32 characters long.", ephemeral=True)
        return

    if member.top_role >= interaction.guild.me.top_role:
        await interaction.response.send_message("I cannot change the nickname of this member because their role is higher than mine.", ephemeral=True)
        return

    try:
        await member.edit(nick=nickname)
        embed = discord.Embed(title="Change Nickname Command", color=discord.Color.blue())
        embed.add_field(name="Member", value=member.mention, inline=False)
        embed.add_field(name="New Nickname", value=nickname, inline=False)
        embed.description = f"{member.mention}'s nickname has been changed to `{nickname}`."
        await interaction.response.send_message(embed=embed)
    except discord.Forbidden:
        await interaction.response.send_message("I do not have permission to change this member's nickname.", ephemeral=True)
    except discord.HTTPException as e:
        await interaction.response.send_message(f"An error occurred: {e}", ephemeral=True)
    except Exception as e:
        await interaction.response.send_message(f"An unexpected error occurred: {e}", ephemeral=True)

# Kick Command
@bot.command()
@commands.has_permissions(kick_members=True)
async def kick(ctx, member: discord.Member, *, reason=None):
    reason = reason or "no reason provided"
    embed = discord.Embed(title="Kick Command", color=discord.Color.red())
    embed.add_field(name="Member", value=member.mention, inline=False)
    embed.add_field(name="Reason", value=reason, inline=False)
    try:
        await member.kick(reason=reason)
        embed.description = f"{member.mention} has been kicked for {reason}"
        await ctx.send(embed=embed)
    except discord.Forbidden:
        embed.description = "I do not have permission to kick this member."
        await ctx.send(embed=embed)
    except discord.HTTPException as e:
        embed.description = f"An error occurred: {e}"
        await ctx.send(embed=embed)

#Member Count
@bot.command(name='membercount', help='Get the total number of members in the server.')
async def member_count(ctx):
    total_members = ctx.guild.member_count
    embed = discord.Embed(title="Server Member Count", color=discord.Color.blue())
    embed.add_field(name="Total Members", value=total_members, inline=False)
    await ctx.send(embed=embed)

#AFK
@bot.command(name='afk', help='Set your AFK status.')
async def set_afk(ctx, *, reason: str = "Away from keyboard"):
    user = ctx.author
    if user.nick and user.nick.startswith("[AFK] "):
        await ctx.send("You are already set as AFK.")
        return

    new_nickname = f"[AFK] {user.display_name}"
    try:
        await user.edit(nick=new_nickname)
        await ctx.send(f"Your AFK status has been set. Reason: {reason}")
    except discord.Forbidden:
        await ctx.send("I don't have permission to change your nickname.")

#Remove AFK
@bot.command(name='remove_afk', help='Remove your AFK status.')
async def remove_afk(ctx):
    user = ctx.author
    if user.nick and user.nick.startswith("[AFK] "):
        new_nickname = user.nick[6:]
        try:
            await user.edit(nick=new_nickname)
            await ctx.send('Your AFK status has been removed.')
        except discord.Forbidden:
            await ctx.send("I don't have permission to change your nickname.")
    else:
        await ctx.send("You are not set as AFK.")

# Ban Command
@bot.command()
@commands.has_permissions(ban_members=True)
async def Ban(ctx, member: discord.Member, *, reason=None):
    reason = reason or "no reason provided"
    embed = discord.Embed(title="Ban Command", color=discord.Color.red())
    embed.add_field(name="Member", value=member.mention, inline=False)
    embed.add_field(name="Reason", value=reason, inline=False)
    try:
        await member.ban(reason=reason)
        embed.description = f"{member.mention} has been successfully banned for {reason}"
        await ctx.send(embed=embed)
    except discord.Forbidden:
        embed.description = "I do not have permission to ban this member."
        await ctx.send(embed=embed)
    except discord.HTTPException as e:
        embed.description = f"An error occurred: {e}"
        await ctx.send(embed=embed)

# Kill Command (Alias for Ban)
@bot.command()
@commands.has_permissions(ban_members=True)
async def kill(ctx, member: discord.Member, *, reason=None):
    reason = reason or "no reason provided"
    embed = discord.Embed(title="Kill Command", color=discord.Color.red())
    embed.add_field(name="Member", value=member.mention, inline=False)
    embed.add_field(name="Reason", value=reason, inline=False)
    try:
        await member.ban(reason=reason)
        embed.description = f"{member.mention} has been murdered because {reason}"
        await ctx.send(embed=embed)
    except discord.Forbidden:
        embed.description = "I do not have permission to kill this member."
        await ctx.send(embed=embed)
    except discord.HTTPException as e:
        embed.description = f"An error occurred: {e}"
        await ctx.send(embed=embed)

# Unban Command
@bot.command()
@commands.has_permissions(ban_members=True)
async def unban(ctx, user: discord.User):
    embed = discord.Embed(title="Unban Command", color=discord.Color.green())
    embed.add_field(name="User", value=user, inline=False)
    try:
        await ctx.guild.unban(user)
        embed.description = f"✅ **Successfully Unbanned!** ✅ {user} has been successfully unbanned!"
        await ctx.send(embed=embed)
    except discord.Forbidden:
        embed.description = "I do not have permission to unban this user."
        await ctx.send(embed=embed)
    except discord.HTTPException as e:
        embed.description = f"An error occurred: {e}"
        await ctx.send(embed=embed)

# Mute Command
@bot.command()
@commands.has_permissions(moderate_members=True)
async def mute(ctx, member: discord.Member, timelimit: str):
    embed = discord.Embed(title="Mute Command", color=discord.Color.orange())
    embed.add_field(name="Member", value=member.mention, inline=False)
    try:
        seconds = 0
        if "s" in timelimit:
            seconds = int(timelimit.strip("s"))
        elif "m" in timelimit:
            seconds = int(timelimit.strip("m")) * 60
        elif "h" in timelimit:
            seconds = int(timelimit.strip("h")) * 3600
        elif "d" in timelimit:
            seconds = int(timelimit.strip("d")) * 86400
        elif "w" in timelimit:
            seconds = int(timelimit.strip("w")) * 604800
        else:
            embed.description = "Invalid time format. Please use 's' for seconds, 'm' for minutes, 'h' for hours, 'd' for days, or 'w' for weeks."
            await ctx.send(embed=embed)
            return
        if seconds <= 0:
            embed.description = "The duration must be a positive number."
            await ctx.send(embed=embed)
            return
        end_time = discord.utils.utcnow() + datetime.timedelta(seconds=seconds)
        await member.edit(timed_out_until=end_time)
        embed.add_field(name="Duration", value=timelimit, inline=False)
        embed.description = f"{member.mention} has been muted for {timelimit}."
        await ctx.send(embed=embed)
    except ValueError:
        embed.description = "Invalid time value. Please enter a valid number."
        await ctx.send(embed=embed)
    except discord.Forbidden:
        embed.description = "I do not have permission to mute this member."
        await ctx.send(embed=embed)
    except discord.HTTPException as e:
        embed.description = f"An error occurred: {e}"
        await ctx.send(embed=embed)

# Unmute Command
@bot.command()
@commands.has_permissions(moderate_members=True)
async def unmute(ctx, member: discord.Member):
    embed = discord.Embed(title="Unmute Command", color=discord.Color.green())
    embed.add_field(name="Member", value=member.mention, inline=False)
    try:
        await member.edit(timed_out_until=None)
        embed.description = f"{member.mention} has been unmuted."
        await ctx.send(embed=embed)
    except discord.Forbidden:
        embed.description = "I do not have permission to unmute this member."
        await ctx.send(embed=embed)
    except discord.HTTPException as e:
        embed.description = f"An error occurred: {e}"
        await ctx.send(embed=embed)

# Warn Command
@bot.command()
@commands.has_permissions(kick_members=True)
async def warn(ctx, member: discord.Member, *, reason="No reason provided."):
    embed = discord.Embed(title="Warn Command", color=discord.Color.yellow())
    embed.add_field(name="Member", value=member.mention, inline=False)
    embed.add_field(name="Reason", value=reason, inline=False)
    try:
        await ctx.send(embed=embed)
        dm_message = f"You have been warned in {ctx.guild.name} for: {reason}"
        await member.send(dm_message)
    except discord.Forbidden:
        embed.description = "I cannot send DMs to this user."
        await ctx.send(embed=embed)

# Purge Command
@bot.command(aliases=["clear"])
async def purge(ctx, amount: int = 5):
    embed = discord.Embed(title="Purge Command", color=discord.Color.blue())
    if amount < 1:
        embed.description = "The amount must be at least 1."
        await ctx.send(embed=embed)
        return
    try:
        deleted = await ctx.channel.purge(limit=amount + 1)
        embed.description = f'{len(deleted) - 1} messages have been cleared'
        await ctx.send(embed=embed)
    except discord.Forbidden:
        embed.description = "I do not have permission to delete messages."
        await ctx.send(embed=embed)
    except discord.HTTPException as e:
        embed.description = f"An error occurred: {e}"
        await ctx.send(embed=embed)
#Say    
@bot.command()
async def say(ctx, *, message: str):
    if ctx.author.name != 'etilethepro':
        await ctx.send("Sorry, you do not have permission to use this command.")
        return

    async with ctx.typing():
        await asyncio.sleep(2)  # Adjust the delay as needed
    await ctx.send(message)

# Define the say application command
@bot.tree.command(name='say', description='Send a message to a specified channel')
async def say(
    interaction: discord.Interaction,
    channel: discord.TextChannel,
    message: str
):
    if interaction.user.name != 'etilethepro':
        await interaction.response.send_message("Sorry, you do not have permission to use this command.", ephemeral=True)
        return

    # Acknowledge the command
    await interaction.response.send_message('Processing your request...')

    # Simulate bot typing
    async with channel.typing():
        await asyncio.sleep(2)  # Adjust the delay as needed

        # Send the message to the specified channel
        try:
            await channel.send(message)
            await interaction.followup.send(f"Message sent to {channel.mention}!")
        except Exception as e:
            await interaction.followup.send(f"Failed to send the message: {e}")
# Command list embed function
def get_help_embed():
    embed = discord.Embed(
        title="Mod Command List",
        description="Here are the commands you can use:",
        color=discord.Color.blue()
    )
    
    commands_list = {
        '!kick': 'Kick a user from the server.',
        '!ban': 'Ban a user from the server.',
        '!unban': 'Unban a user from the server.',
        '!mute': 'Mute a user in the server.',
        '!unmute': 'Unmute a user in the server.',
        '!warn': 'Warn a user.',
        '!purge': 'Delete a specified number of messages from the channel.',
        '/create_role': 'Creates a role and you can select its permissions',
        '/edit_role': 'Allows you to edit a roles permission or name',
        '/delete_role': 'Allows you to delete a role',
        '/give_role': 'Allows you to give a user a role',
        '/change_nickname': 'Allows you to change the nickname of a user'
    }

    for command, description in commands_list.items():
        embed.add_field(name=command, value=description, inline=False)

    return embed

# Help command
@bot.command(name='mod-commands', help='Display the list of available commands.')
async def help(ctx):
    embed = get_help_embed()
    await ctx.send(embed=embed)

# Command list embed for specific commands
def get_specific_commands_embed():
    embed = discord.Embed(
        title="Command List",
        description="Here are the specific commands you can use:",
        color=discord.Color.green()
    )
    
    commands_list = {
        '!afk': 'Set yourself as away from keyboard (AFK).',
        '!remove_afk': 'Remove your AFK status.',
        '!membercount': 'Show the number of members in the server.',
        '!level': 'Check your level and XP.',
    }

    for command, description in commands_list.items():
        embed.add_field(name=command, value=description, inline=False)

    return embed

# General help command

def get_help_embed():
    embed = discord.Embed(
        title="Currency Command List",
        description="Here are the commands you can use:",
        color=discord.Color.blue()
    )
    
    commands_list = {
        '!blackjack': 'say !blackjack ("coin amount") and it starts a game of blackjack.',
        '!slots': 'say !slots ("coin amount") and it spins a slot machine.',
        '!balance': 'Checks your coin balance.',
        '!transfer': 'Allows you to transfer coins to a user',
        '/blackjack': 'Starts a game of blackjack.',
        '/slots': 'Spins a slot machine.',
        '/balance': 'Checks your balance.',
        '/transfer': 'Allows you to transfer coins to someone.'
    }

    for command, description in commands_list.items():
        embed.add_field(name=command, value=description, inline=False)

    return embed

# Hybrid command for both prefix and slash usage
@bot.hybrid_command(name='currency-commands', help='Display the list of available commands.')
async def currency_commands(ctx: commands.Context):
    embed = get_help_embed()
    await ctx.send(embed=embed)

# Math Commands

# Add Command
@bot.command()
async def add(ctx, *args):
    if len(args) < 2:
        await ctx.send("You need to provide at least two numbers.")
        return

    try:
        numbers = list(map(float, args))  # Convert arguments to floats
        result = sum(numbers)  # Sum all the numbers
        
        embed = discord.Embed(title="Addition Result", color=discord.Color.blue())
        operation = " + ".join(map(str, numbers))  # Create a string representation of the operation
        embed.add_field(name="Operation", value=operation, inline=False)
        embed.add_field(name="Result", value=result, inline=False)
        await ctx.send(embed=embed)
    
    except ValueError:
        await ctx.send("Please provide valid numbers.")
        
# Multiply Command
@bot.command()
async def multiply(ctx, *args):
    if len(args) < 2:
        await ctx.send("You need to provide at least two numbers.")
        return

    try:
        numbers = list(map(float, args))  # Convert the arguments to floats
        result = numbers[0]
        for num in numbers[1:]:
            result *= num
        
        embed = discord.Embed(title="Multiplication Result", color=discord.Color.green())
        operation = " * ".join(map(str, numbers))  # Create a string representation of the operation
        embed.add_field(name="Operation", value=operation, inline=False)
        embed.add_field(name="Result", value=result, inline=False)
        await ctx.send(embed=embed)
    
    except ValueError:
        await ctx.send("Please provide valid numbers.")

#Subtraction
@bot.command()
async def subtract(ctx, *args):
    if len(args) < 2:
        await ctx.send("You need to provide at least two numbers.")
        return

    try:
        numbers = list(map(float, args))  # Convert the arguments to floats
        result = numbers[0]
        for num in numbers[1:]:
            result -= num
        
        embed = discord.Embed(title="Subtraction Result", color=discord.Color.green())
        embed.add_field(name="Operation", value=f"{' - '.join(map(str, numbers))}", inline=False)
        embed.add_field(name="Result", value=result, inline=False)
        await ctx.send(embed=embed)
    
    except ValueError:
        await ctx.send("Please provide valid numbers.")

# Divide Command
@bot.command()
async def divide(ctx, *args):
    if len(args) < 2:
        await ctx.send("You need to provide at least two numbers.")
        return

    try:
        numbers = list(map(float, args))  # Convert arguments to floats
        
        result = numbers[0]
        for num in numbers[1:]:
            if num == 0:
                raise ZeroDivisionError
            result /= num
        
        embed = discord.Embed(title="Division Result", color=discord.Color.orange())
        operation = " / ".join(map(str, numbers))  # Create a string representation of the operation
        embed.add_field(name="Operation", value=operation, inline=False)
        embed.add_field(name="Result", value=result, inline=False)
    
    except ZeroDivisionError:
        embed = discord.Embed(title="Division Error", description="Cannot divide by zero.", color=discord.Color.red())
    
    except ValueError:
        embed = discord.Embed(title="Invalid Input", description="Please provide valid numbers.", color=discord.Color.red())
    
    await ctx.send(embed=embed)

# Roll Command
@bot.command()
async def roll(ctx, dice: str):
    embed = discord.Embed(title="Dice Roll", color=discord.Color.purple())
    try:
        rolls, limit = map(int, dice.split('d'))
    except Exception:
        embed.description = 'Format has to be in NdN!'
        await ctx.send(embed=embed)
        return
    result = ', '.join(str(random.randint(1, limit)) for _ in range(rolls))
    embed.add_field(name="Rolls", value=result, inline=False)
    await ctx.send(embed=embed)

# Choose Command
@bot.command(description='For when you wanna settle the score some other way')
async def choose(ctx, *choices: str):
    embed = discord.Embed(title="Choice Selector", color=discord.Color.gold())
    
    if random.randint(1, 5) == 1:
        embed.description = "Neither"
    else:
        if not choices:
            embed.description = 'You need to provide at least one choice.'
        else:
            choice = random.choice(choices)
            embed.add_field(name="Chosen Option", value=choice, inline=False)
    
    await ctx.send(embed=embed)
# Repeat Command
@bot.command()
async def repeat(ctx, times: int, *, content='repeating...'):
    if times < 1:
        embed = discord.Embed(title="Repeat Command", color=discord.Color.red())
        embed.description = "The number of repetitions must be at least 1."
        await ctx.send(embed=embed)
        return
    
    for _ in range(times):
        await ctx.send(content)

# Joined Command
@bot.command()
async def joined(ctx, member: discord.Member):
    embed = discord.Embed(title="Member Joined", color=discord.Color.blue())
    embed.add_field(name="Member", value=member.name, inline=False)
    embed.add_field(name="Joined At", value=discord.utils.format_dt(member.joined_at), inline=False)
    await ctx.send(embed=embed)

# Cool Command Group
@bot.group()
async def cool(ctx):
    if ctx.invoked_subcommand is None:
        embed = discord.Embed(title="Cool Command", color=discord.Color.greyple())
        embed.description = f'No, {ctx.subcommand_passed} is not cool. Etile is cool though.'
        await ctx.send(embed=embed)

@cool.command(name='bot')
async def _bot(ctx):
    embed = discord.Embed(title="Bot Coolness", color=discord.Color.blue())
    embed.description = 'Yes, the bot is cool.'
    await ctx.send(embed=embed)

@bot.event
async def on_message(message):
    if message.content.startswith('!shirtlessjet'):
        if random.randint(1, 1) == 1:
            await message.channel.send(file=discord.File('Shirtlessjet.png'))
        else:
            await message.channel.send("You didn't get it this time.")

    await bot.process_commands(message)
            
@bot.group()
async def win(ctx):
    await ctx.send('Nah, I’d win.')

@bot.group()
async def etile(ctx):
    await ctx.send('Etile Is Cool.')

async def main():
    await load_extensions()
    await bot.start('MTI3MTEwNDM5NTUyMTU2MDY3OA.GfXX4-.CgPetDr3tr02Qk181Lmkm3YLAJCk1HckMVnnUI')

if __name__ == "__main__":
    asyncio.run(main())